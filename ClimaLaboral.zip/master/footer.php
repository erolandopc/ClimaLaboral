<footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Gerencia de Informática Institucional</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2016 <a href="http://www.mop.gob.sv">Ministerio de Obras Públicas, Transporte, Vivienda y Desarrollo Urbano</a>.</strong> Derechos reservados.
  </footer>